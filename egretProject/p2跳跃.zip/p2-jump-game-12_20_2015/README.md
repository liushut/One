## p2 jump game

这是一款使用物理p2制作的小游戏


详情可以查看源码,入口类

Bootstrap
如果是下载源码运行，解压后，打开 source 下 code 目录，空白处键盘Shift+鼠标右键打开命令行

可能需要执行：

egret upgrade (升级版本，由于引擎更新比较快，此处执行命令升级为最新版本)

egret build -e （编译项目与引擎）

egret startserver （启动一个http服务，查看效果）