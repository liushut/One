declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare class startButtonSkin extends eui.Skin{
}
