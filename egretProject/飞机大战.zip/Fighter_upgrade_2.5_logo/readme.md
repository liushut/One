## 打飞机游戏

> 本教程示例转载自 NeoGuo ，原文教程地址：
[Egret框架入门教程 - 使用Egret创建一个打飞机的游戏](https://github.com/NeoGuo/html5-documents/blob/master/egret/sample-1.md)



