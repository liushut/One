﻿module game {

    export interface IDecoration {
        OnUpdate(type: number, value: any): void;
    }


}