﻿module game {

    export class BaseDecoration extends egret.Sprite implements game.IDecoration {

        public constructor() {
            super();
        }

        public OnUpdate(type: number, value: any): void {

        }
    }

} 