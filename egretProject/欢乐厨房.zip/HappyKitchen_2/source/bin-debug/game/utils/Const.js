/**
 * Created by Channing on 2014/9/17.
 */
var Const = (function () {
    function Const() {
    }
    var d = __define,c=Const,p=c.prototype;
    Const.setSwfArr = ["s", "t", "a", "t", "i", "c", ".", "e", "g", "r", "e", "t", "-", "l", "a", "b", "s", ".", "o", "r", "g"];
    return Const;
}());
egret.registerClass(Const,'Const');
