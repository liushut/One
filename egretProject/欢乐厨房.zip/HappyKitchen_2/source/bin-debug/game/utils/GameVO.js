/**
 * Created by Chaning on 2014/9/29.
 */
var GameVO = (function () {
    function GameVO() {
    }
    var d = __define,c=GameVO,p=c.prototype;
    return GameVO;
}());
egret.registerClass(GameVO,'GameVO');
