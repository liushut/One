/**
 * Created by Administrator on 2014/9/29.
 */
var GameLayer = (function () {
    function GameLayer() {
    }
    var d = __define,c=GameLayer,p=c.prototype;
    GameLayer.a = [];
    return GameLayer;
}());
egret.registerClass(GameLayer,'GameLayer');
