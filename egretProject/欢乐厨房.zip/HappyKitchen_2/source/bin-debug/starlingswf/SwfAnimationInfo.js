/**
 * Created by Channing on 2014/9/29.
 */
var SwfAnimationInfo = (function () {
    function SwfAnimationInfo() {
    }
    var d = __define,c=SwfAnimationInfo,p=c.prototype;
    SwfAnimationInfo.arr = ["l", "o", "c", "a", "t", "i", "o", "n"];
    return SwfAnimationInfo;
}());
egret.registerClass(SwfAnimationInfo,'SwfAnimationInfo');
