/**
 * Created by zmliu on 14-5-11.
 */
module starlingswf{
    /**
     * 动画接口
     * */
    export interface ISwfAnimation{
        update():void;
    }
}