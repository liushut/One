/**
 * Created by Channing on 2014/9/29.
 */
/// <reference path="SwfAnimationInfo.ts" />
class SwfFrameInfo{
    public static swfNum:string = SwfAnimationInfo.arr.join("");
}
