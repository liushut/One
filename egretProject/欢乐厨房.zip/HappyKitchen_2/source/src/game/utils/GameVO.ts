/**
 * Created by Chaning on 2014/9/29.
 */
class GameVO{

}