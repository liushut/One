/**
 * Created by Channing on 2014/9/17.
 */
class Const{
    public static SCENT_WIDTH:number;
    public static SCENT_HEIGHT:number;
    public static GamePoxY:number;
    public static setSwfArr:Array<any> = ["s","t","a","t","i","c",".","e","g","r","e","t","-","l","a","b","s",".","o","r","g"];

}