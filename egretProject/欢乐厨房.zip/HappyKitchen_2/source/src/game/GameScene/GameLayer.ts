/**
 * Created by Administrator on 2014/9/29.
 */
class GameLayer{
    public static a:Array<any> = [];
}