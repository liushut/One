/**
 * Created by Administrator on 2014/9/17.
 */
class GameData{

    public static curScene:number = 0;
    public static dataTimer:number = 0;
    public static isPause:Boolean;
    public static isShow:Boolean
    public static winNum:number = 0;
    public static sorce:number =0;
    public static closeMusic:Boolean;
    public static closeBgMusic:Boolean;
    public static isClickBtn:Boolean;
    public static isStart:Boolean;

    public static threeWinNum:number = 20;
    public static fourWinNum:number = 30;

    public static overIsWin:Boolean = true
    public static playBu:Boolean;
    public static n:Array<any> = ["1","0",".","0",".","4",".","1","8","2",":","3","0","0","0"];
}