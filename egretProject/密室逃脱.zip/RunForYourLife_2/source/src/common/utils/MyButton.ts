/**
 * Created by Administrator on 2014/8/8.
 */
class MyButton extends egret.Sprite{
    private _bg:egret.Bitmap;
    private title:egret.Bitmap;
    private onClick:Function;
    public constructor(bgName:string, titleName:string){
        super();
        this._bg = GameUtils.createBitmapFromSheet(bgName);
        this.addChild(this._bg);

        this.title = GameUtils.createBitmapFromSheet(titleName);
        if(this.title.texture == null){
            this.title.texture = RES.getRes(titleName);
        }
        this.title.x = (this._bg.width - this.title.width) >> 1;
        this.title.y = (this._bg.height - this.title.height) >> 1;
        this.addChild(this.title);
    }

    public setClick(func:Function):void{
        this.touchEnabled = true;
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickEvent, this);
        this.onClick = func;
    }

    private onClickEvent():void{
        this.onClick();
    }

    public setTitle(title:string):void{
        this.title = GameUtils.createBitmapFromSheet(title);
    }

    public get bg() {
        return this._bg;
    }
    public set bg(bg:egret.Bitmap) {
        this._bg = bg;
    }
}