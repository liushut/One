/**
 * Created by ismole on 14-8-8.
 */
class MapLayer {
    public constructor(){

    }

   /**
     * 得到
     */
}