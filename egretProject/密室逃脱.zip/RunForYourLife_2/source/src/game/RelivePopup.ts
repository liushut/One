/**
 * Created by husong on 14/11/4.
 */
class RelivePopup extends egret.DisplayObjectContainer {
    private btnRelive:MyButton;
    public btnOver:MyButton;
    constructor () {
        super();

        this.addChildAt(this.getMask(),0);

        this.btnRelive = new MyButton("btn_y", "btn_zaiwan");
        this.btnRelive.setTitle("fuhuo");
        this.btnRelive.x = 131;
        this.btnRelive.y = 245;
//        this.tryBtn.setClick(this.onReliveClick);
        this.btnRelive.setClick(this.onReliveClick);
        this.addChild(this.btnRelive);

        this.btnOver = new MyButton("btn_b", "btn_zaiwan");
        this.btnOver.setTitle("jieshu");
        this.btnOver.x = 131;
        this.btnOver.y = 351;
        this.addChild(this.btnOver);
    }

    private onReliveClick():void {
        //GameControl.getInstance().onReliveHandler();
    }

    private getMask():egret.Sprite {
        var spr = new egret.Sprite();
        spr.graphics.beginFill(0x000000,0.4);
        spr.graphics.drawRect(0,0,Consts.GAME_WIDTH,Consts.GAME_HEIGHT);
        spr.graphics.endFill();
        return spr;
    }
}