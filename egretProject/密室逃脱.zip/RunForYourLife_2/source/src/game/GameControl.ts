/**
 * Created by ismole on 14-8-8.
 */
class  GameControl extends egret.Sprite
{

    private static _gameControl:GameControl = null;
    public static getInstance():GameControl {

        if(!GameControl._gameControl){
            GameControl._gameControl = new GameControl();
        }
        return GameControl._gameControl;
    }

    private currStage:egret.DisplayObjectContainer;

    private  startgame:StartGameLayer;
    private  gameScene:GameSceneLayer;
    private  gameoverGame:GameOverLayer;
    private  bgImag:egret.Bitmap;


    public constructor()
    {
        super();
        this.startgame= new StartGameLayer();
        this.gameScene = new GameSceneLayer();
        this.gameoverGame = new GameOverLayer();

    }

    public setStageHandler(stage:egret.DisplayObjectContainer):void
    {
        this.currStage = stage;

        this.bgImag = GameUtils.createBitmapByName("bgImage");
        this.bgImag.width = 480;
        this.bgImag.height = 800;
        this.currStage.addChild(this.bgImag );
    }
    public startGameHandler():void
    {
        if(this.gameScene && this.gameScene.parent){
            GameUtils.removeChild(this.gameScene)
        }
        if(this.gameoverGame && this.gameoverGame.parent){
            GameUtils.removeChild(this.gameoverGame)
        }
        this.currStage.addChild(this.startgame);
        GameApp.xia.visible = true;
    }

    public onGameSceneHandler():void
    {
        if(this.startgame && this.startgame.parent){
            GameUtils.removeChild(this.startgame)
        }
        if(this.gameoverGame && this.gameoverGame.parent){
            GameUtils.removeChild(this.gameoverGame)
        }
        this.currStage.addChild(this.gameScene);
        GameApp.xia.visible = false;
    }

    public showGameOverSceneHandler():void{

        if(this.startgame && this.startgame.parent){
            GameUtils.removeChild(this.startgame)
        }
        if(this.gameScene && this.gameScene.parent){
            GameUtils.removeChild(this.gameScene)
        }
        this.currStage.addChild(this.gameoverGame);
        GameApp.xia.visible = true;
    }



    public getGameOverDisplay():GameOverLayer
    {
        return  this.gameoverGame;

    }


}