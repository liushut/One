/**
 * Created by ismole on 14-8-8.
 */
class GameOverLayer extends egret.Sprite {
    private gameoverbg1:egret.Bitmap;
    private shibaibg:egret.Bitmap;
    private maxScoreIm:egret.Bitmap;
    private currScoreIm:egret.Bitmap;
    private tryBtn:MyButton;
    private strutBtn:MyButton;

    private scoreNum:SpecialNumber;
    private recordNum:SpecialNumber;

    //添加死亡动画
    public constructor() {
        super();
        this.init();
    }

    private init():void {
        this.gameoverbg1 = GameUtils.createBitmapFromSheet("bg_wenzi");
        this.gameoverbg1.x = 76;
        this.gameoverbg1.y = 0;
        this.addChild(this.gameoverbg1);

        this.shibaibg = GameUtils.createBitmapFromSheet("shibai");
        this.shibaibg.x = 140;
        this.shibaibg.y = 84;
        this.addChild(this.shibaibg);

        this.maxScoreIm = GameUtils.createBitmapFromSheet("zuigaojilu");
        this.maxScoreIm.x = 278;
        this.maxScoreIm.y = 248;
        this.addChild(this.maxScoreIm);

        this.currScoreIm = GameUtils.createBitmapFromSheet("fenshu");
        this.currScoreIm.x = 108;
        this.currScoreIm.y = 248;
        this.addChild(this.currScoreIm);

        this.tryBtn = new MyButton("btn_y", "btn_zaiwan");
        this.tryBtn.x = 131;
        this.tryBtn.y = 371;
        this.tryBtn.setClick(this.onTryGameClick)
        this.addChild(this.tryBtn);

        this.strutBtn = new MyButton("btn_b", "btn_xuanya");
        this.strutBtn.x = 131;
        this.strutBtn.y = 481;
        this.addChild(this.strutBtn);
        this.strutBtn.setClick(this.onStrutGameClik.bind(this))

        if(egret.Capabilities.runtimeType == egret.RuntimeType.NATIVE){
            this.removeChild(this.strutBtn);
        }

        this.scoreNum = new SpecialNumber();
        this.scoreNum.x = 135;
        this.scoreNum.y = 283;
        this.addChild(this.scoreNum);

        this.recordNum = new SpecialNumber();
        this.recordNum.x = 327;
        this.recordNum.y = 283;
        this.addChild(this.recordNum);
    }

    /**
     * 设置游戏结束界面数据
     */
    public setGameOverDataHandler(score:number = 20, record:number = 57):void {
        this.scoreNum.setData(score.toString());
        this.recordNum.setData(record.toString());
        //EgretShare.setShareContent("得了" + score + "分！手心全是汗！这游戏实在TM太惊险了！谁敢来挑战？");
    }

    private onTryGameClick():void {
       console.log("try again");
       GameControl.getInstance().onGameSceneHandler();
    }

    private weixinContainer:egret.DisplayObjectContainer;

    private onStrutGameClik():void {
        console.log("炫耀下~");
        //EgretShare.share();
    }

    public onStageTouch():void {
        var stage = this.stage;
        stage.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onStageTouch, this);
        stage.touchChildren = true;
        stage.removeChild(this.weixinContainer);
    }
}