/**
 * 玩家的状态
 * Created by cf on 14-8-8.
 */
class PlayerLayer extends egret.Sprite
{
    private playerStateType:any ={}
    private playerDirection:any ={};


    private speedX:number ;//移动速度

    public constructor()
    {

        super();
        this.playerDirection["center"] =0 ;
        this.playerDirection["left"] =1 ;
        this.playerDirection["right"] =2;

        this.playerStateType["normal"] =0 ;
        this.playerStateType["died"] = 1;
        this.playerStateType["stop"] =2;

    }
}