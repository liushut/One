/**
 * 特效的播放类
 * Created by ismole on 14-8-8.
 */
class EffectLayer
{
    public constructor()
    {

    }
}
