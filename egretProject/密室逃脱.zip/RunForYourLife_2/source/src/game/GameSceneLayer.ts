/**
 * 游戏场景
 * Created by ismole on 14-8-8.
 */
class GameSceneLayer extends egret.Sprite {
    private titleImg:egret.Bitmap;
    private maxScore:egret.Bitmap;
    private currLv:egret.Bitmap;

    private scoreKuang:egret.Bitmap;
    private lvKuang:egret.Bitmap;
    private bg:egret.Texture;
    private topSptite:egret.Sprite;
    private bottomSptite:egret.Sprite;
    private bgBitmaps:Array<egret.Bitmap>;
    private topRects:Array<egret.Rectangle>;
    private bottomRects:Array<egret.Rectangle>;
    private spaceArr:Array<number> = [50, 70, 90, 110];
    private topLine:egret.Shape;
    private bottomLine:egret.Shape;


    private lvNum:SpecialNumber;
    private recordNum:SpecialNumber;

    private currLevel:number;
    private currMaxScore:number;
    private role:Role;
    private rolePosIndex:number;
    private shake1:Shake;
    private shake2:Shake;
    private topContianer:egret.Sprite;
    private bottomContianer:egret.Sprite;
    private dieNum:number;
    private score:number;

    public constructor() {
        super();
        this.initUI();
    }

    private initUI():void {
        this.shake1 = new Shake();
        this.shake2 = new Shake();

        this.bg = RES.getRes("bg_qiang");
        var bg = new egret.Bitmap(this.bg);

        bg.mask = new egret.Rectangle(0,Consts.GAME_HEIGHT,Consts.GAME_WIDTH, 300);
        this.addChild(bg);

        this.bgBitmaps = new Array<egret.Bitmap>();

        this.topContianer = new egret.Sprite();
        this.addChild(this.topContianer);
        this.topSptite = new egret.Sprite();
        this.topContianer.addChild(this.topSptite);
        this.topLine = new egret.Shape();
        this.topContianer.addChild(this.topLine);

        this.bottomContianer = new egret.Sprite();
        this.addChild(this.bottomContianer);
        this.bottomSptite = new egret.Sprite();
        this.bottomContianer.addChild(this.bottomSptite);
        this.bottomLine = new egret.Shape();
        this.bottomContianer.addChild(this.bottomLine);

        this.topRects = new Array<egret.Rectangle>();
        this.bottomRects = new Array<egret.Rectangle>();

        this.titleImg = GameUtils.createBitmapFromSheet("bg_shangkuang");
        this.addChild(this.titleImg);

        this.scoreKuang = GameUtils.createBitmapFromSheet("kuang");
        this.scoreKuang.x = 5;
        this.addChild(this.scoreKuang);

        this.lvKuang = GameUtils.createBitmapFromSheet("kuang");
        this.lvKuang.scaleX = -1;
        this.lvKuang.x = 466;
        this.addChild(this.lvKuang);

        this.maxScore = GameUtils.createBitmapFromSheet("fenshu");
        this.maxScore.x = 40;
        this.maxScore.y = 15;
        this.addChild(this.maxScore);

        this.currLv = GameUtils.createBitmapFromSheet("guanqia");
        this.currLv.x = 368;
        this.currLv.y = 15;
        this.addChild(this.currLv);

        this.lvNum = new SpecialNumber();
        this.lvNum.x = 393;
        this.lvNum.y = 50;
        this.addChild(this.lvNum);

        this.recordNum = new SpecialNumber();
        this.recordNum.x = 73;
        this.recordNum.y = 50;
        this.addChild(this.recordNum);

        this.currLevel = 1;
        this.currMaxScore = 0;
        this.lvNum.setData(this.currLevel.toString());
        this.recordNum.setData(this.currMaxScore.toString());

        this.role = new Role();
        this.addChild(this.role);

        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdd, this);
    }

    private onAdd():void {
        this.dieNum = 0;
        this.score = 0;
        this.currLevel = 1;
        this.refreshScore();
        this.initData();
        egret.setTimeout(this.start, this, 100);
    }

    private refreshScore():void {
        this.lvNum.setData(this.currLevel.toString());
        this.recordNum.setData(this.score.toString());
    }

    private refurbish():void {
        this.initData();
        this.start();
    }

    private start():void {
        this.stage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        egret.setTimeout(this.shakeRun, this, 1000);
    }

    private shakeRun():void {
        this.shake1.run(this.topContianer, 5, this.land.bind(this));
    }

    private land():void {
        this.stage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        egret.Tween.get(this.topContianer).to({"y": 0}, 100).call(function ():void {
            this.landOver();
        }.bind(this));
    }

    public landOver():void {
        this.checkState();
        this.shake1.run(this.topContianer, 3);
        this.shake2.run(this.bottomContianer, 3, this.checkResult.bind(this));
    }

    private checkState():void {
        var space:number = this.getSpace();
        if (space == 0) {
            this.role.setState(Role.STATE5);
        } else if (space == this.spaceArr[2]) {
            this.role.setState(Role.STATE4);
        } else if (space == this.spaceArr[0]) {
            this.role.setState(Role.STATE3);
        } else if (space == this.spaceArr[1]) {
            this.role.setState(Role.STATE2);
        }
        if (space == 0) {
            this.setRolePos(this.rolePosIndex, -10, 4);
        }
    }

    private checkResult():void {
        var space:number = this.getSpace();
        var _this = this;
        if (space == 0) {
            this.dieNum++;
            if (this.dieNum == 1) {
                this.role.stop();

                egret.setTimeout(function () {
                    GameControl.getInstance().showGameOverSceneHandler();
                    GameControl.getInstance().getGameOverDisplay().setGameOverDataHandler(_this.score, _this.currMaxScore);
                }, this, 1000);

                return;
            }
        } else {
            this.currLevel++;
            this.score += 10;
            if (this.score > this.currMaxScore) {
                this.currMaxScore = this.score;
            }
            this.refreshScore();
        }
        egret.setTimeout(this.refurbish, this, 1000);
    }

    private getSpace():number {
        var top:egret.Rectangle = this.topRects[this.rolePosIndex];
        var bottom:egret.Rectangle = this.bottomRects[this.rolePosIndex];
        return Consts.GAME_HEIGHT - top.height - bottom.height;
    }

    private onClick(e:egret.TouchEvent):void {
        var i:number = 0;
        var len:number = this.bottomRects.length;
        for (i; i < len; i++) {
            var rec:egret.Rectangle = this.bottomRects[i];
            if (e.stageX > rec.x && e.stageX < rec.x + rec.width) {
                this.setRolePos(i);
                break;
            }
        }
    }

    private initData():void {
        this.role.setState(Role.STATE1);
        this.role.play();

        this.topRects.splice(0, this.topRects.length);
        this.bottomRects.splice(0, this.bottomRects.length);

        var min:number = 150;
        var w:number = 60;
        var flag:boolean = false;
        var len:number = 8;
        for (var i:number = 0; i < len; i++) {
            var h:number = min + Math.floor(Math.random() * 8) * 10;
            this.bottomRects.push(new egret.Rectangle(i * w, Consts.GAME_HEIGHT - h, w, h));

            h = Consts.GAME_HEIGHT - h;
            if (Math.random() < 0.2 || (!flag && i == len - 1)) {
                var index:number = Math.floor(Math.random() * this.spaceArr.length);
                h -= this.spaceArr[index];
                flag = true;
            }
            this.topRects.push(new egret.Rectangle(i * w, 0, w, h));
        }


        this.fullFront(this.topSptite, this.topRects);
        this.fullFront(this.bottomSptite, this.bottomRects, true);
        this.drawLine();

        this.topContianer.y = -200;

        this.setRolePos(3, 17, 0, true);
    }

    private setRolePos(index:number, offY:number = 17, offX:number = 0, isInit:boolean = false):void {
        if (!isInit) {//一次只移动一格
            if (this.rolePosIndex > index) {
                index = this.rolePosIndex - 1;
            }
            else if (this.rolePosIndex < index) {
                index = this.rolePosIndex + 1;
            }
        }
        this.rolePosIndex = index;
        var rec:egret.Rectangle = this.bottomRects[index];
        this.role.x = rec.x + rec.width / 2 + offX;
        this.role.y = rec.y + offY;
    }

    private drawLine():void {
        var lineH:number = 10;
        this.topLine.graphics.clear();
        this.topLine.graphics.lineStyle(lineH, 0x33E7FE);
        this.bottomLine.graphics.clear();
        this.bottomLine.graphics.lineStyle(lineH, 0x33E7FE);
        this.drawTopLine(lineH / 2);
        this.drawBottomLine(lineH / 2);
        this.topLine.graphics.endFill();
        this.bottomLine.graphics.endFill();
    }

    private drawTopLine(lineH:number):void {
        var len:number = this.topRects.length;
        for (var i:number = 0; i < len; i++) {
            var rec:egret.Rectangle = this.topRects[i];
            if (i == 0) {
                this.topLine.graphics.moveTo(rec.x, rec.height);
                this.topLine.graphics.lineTo(rec.x + rec.width, rec.height);
            } else {
                this.topLine.graphics.lineTo(rec.x, rec.height);
                this.topLine.graphics.lineTo(rec.x + rec.width, rec.height);
            }
        }
    }

    private drawBottomLine(lineH:number):void {
        var len:number = this.bottomRects.length;
        for (var i:number = 0; i < len; i++) {
            var rec:egret.Rectangle = this.bottomRects[i];
            if (i == 0) {
                this.bottomLine.graphics.moveTo(rec.x, rec.y + lineH);
                this.bottomLine.graphics.lineTo(rec.x + rec.width, rec.y + lineH);
            } else {
                this.bottomLine.graphics.lineTo(rec.x, rec.y + lineH);
                this.bottomLine.graphics.lineTo(rec.x + rec.width, rec.y + lineH);
            }
        }
    }

    private fullFront(bgSptite:egret.Sprite, rects:Array<egret.Rectangle>, isBottom:boolean = false):void {
        bgSptite.cacheAsBitmap = false;

        this.clearBg(bgSptite);

        var len:number = rects.length;
        for (var i:number = 0; i < len; i++) {
            var rec:egret.Rectangle = rects[i];
            var bitmap:egret.Bitmap;
            if (this.bgBitmaps.length) {
                bitmap = this.bgBitmaps.pop();
            } else {
                bitmap = new egret.Bitmap();
                bitmap.texture = this.bg;
            }
            bitmap.scrollRect = rec;

            bitmap.x = rec.x;
            bitmap.y = rec.y;

            bgSptite.addChild(bitmap);
        }

    }

    private clearBg(bgSptite:egret.Sprite):void {
        while (bgSptite.numChildren) {
            var bitmap:egret.Bitmap = <egret.Bitmap>bgSptite.getChildAt(0);
            if (bitmap) {
                bgSptite.removeChild(bitmap);
                this.bgBitmaps.push(bitmap);
            }
        }
    }

}
