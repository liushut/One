/**
 * Created by Administrator on 2014/8/8.
 */
class Role extends egret.Sprite{
    public static STATE1:number = 0;
    public static STATE2:number = 1;
    public static STATE3:number = 2;
    public static STATE4:number = 3;
    public static STATE5:number = 4;
    public static FRAMES:Array<any> = [
        ["0020003", "0020004", "0020005", "0020006","0020007"],
        ["0020008"],
        ["0020009", "0020010"],
        ["0020011", "0020012"],
        ["xue0001", "xue0002", "xue0003", "xue0004", "xue0005"]
    ];

    private body:egret.Bitmap;
    private state:number;
    private currFrames:Array<any>;
    private currFrameIndex:number = 0;
    private runFlag:number;
    private isLoop:boolean;

    public constructor(){
        super();
        this.body = new egret.Bitmap();
        this.body.texture = GameUtils.getTextureFromSheet(Role.FRAMES[0][0], "roleRes");
        console.log(this.body.width);
        this.body.anchorOffsetX = this.body.width * 0.5;
        this.addChild(this.body);
    }

    public setState(state:number):void{
        this.state = state;
        if(this.state == Role.STATE5){
            this.isLoop = false;
            console.log("body height"+this.body.height);
            this.body.anchorOffsetY = this.body.height * 0;
        }else{
            this.isLoop = true;
            console.log("isloop body height"+this.body.height);
            this.body.anchorOffsetY = this.body.height * 1;
        }

        if(this.state == Role.STATE3 || this.state == Role.STATE4){
            this.currFrames = [];
            if(Math.random() > 0.5){
                this.currFrames.push(Role.FRAMES[this.state][0]);
            }else{
                this.currFrames.push(Role.FRAMES[this.state][1]);
            }
        }else{
            this.currFrames = Role.FRAMES[this.state];
        }
        this.currFrameIndex = 0;
        this.setBody();
    }

    private setBody():void{
        this.body.texture = GameUtils.getTextureFromSheet(this.currFrames[this.currFrameIndex], "roleRes");
        this.body.anchorOffsetX = this.body.width * 0.5;
        if(this.state == Role.STATE5){
            this.isLoop = false;
            console.log("body height"+this.body.height);
            this.body.anchorOffsetY = this.body.height * 0;
        }else{
            this.isLoop = true;
            console.log("isloop body height"+this.body.height);
            this.body.anchorOffsetY = this.body.height * 1;
        }
    }

    private run():boolean{
        this.runFlag ++;
        if(this.runFlag > 4){
            this.runFlag = 0;
        }
        if(this.runFlag != 0){
            return;
        }
        var gotoFrameIndex:number = this.currFrameIndex + 1;
        if(gotoFrameIndex == this.currFrames.length){
            if(this.isLoop){
                gotoFrameIndex = 0;
            }else{
                gotoFrameIndex = this.currFrameIndex;
            }
        }
        if(gotoFrameIndex != this.currFrameIndex){
            this.currFrameIndex = gotoFrameIndex;
            this.setBody();
        }
        return false;
    }

    public play():void{
        egret.startTick(this.run,this);
        this.runFlag = 0;
    }

    public stop():void{
        egret.stopTick(this.run,this);
    }
}