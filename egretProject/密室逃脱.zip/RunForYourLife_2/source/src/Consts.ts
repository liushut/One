/**
 * Created by Administrator on 2014/6/13.
 */
class Consts{
    public static GAME_WIDTH:number = 480;
    public static GAME_HEIGHT:number = 650;
}
