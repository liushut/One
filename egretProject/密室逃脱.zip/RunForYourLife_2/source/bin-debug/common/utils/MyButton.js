/**
 * Created by Administrator on 2014/8/8.
 */
var MyButton = (function (_super) {
    __extends(MyButton, _super);
    function MyButton(bgName, titleName) {
        _super.call(this);
        this._bg = GameUtils.createBitmapFromSheet(bgName);
        this.addChild(this._bg);
        this.title = GameUtils.createBitmapFromSheet(titleName);
        if (this.title.texture == null) {
            this.title.texture = RES.getRes(titleName);
        }
        this.title.x = (this._bg.width - this.title.width) >> 1;
        this.title.y = (this._bg.height - this.title.height) >> 1;
        this.addChild(this.title);
    }
    var d = __define,c=MyButton,p=c.prototype;
    p.setClick = function (func) {
        this.touchEnabled = true;
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickEvent, this);
        this.onClick = func;
    };
    p.onClickEvent = function () {
        this.onClick();
    };
    p.setTitle = function (title) {
        this.title = GameUtils.createBitmapFromSheet(title);
    };
    d(p, "bg"
        ,function () {
            return this._bg;
        }
        ,function (bg) {
            this._bg = bg;
        }
    );
    return MyButton;
}(egret.Sprite));
egret.registerClass(MyButton,'MyButton');
