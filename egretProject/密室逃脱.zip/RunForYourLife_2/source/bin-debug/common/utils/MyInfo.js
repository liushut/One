/**
 * Created by ismole on 14-8-8.
 */
var MyInfo = (function (_super) {
    __extends(MyInfo, _super);
    function MyInfo() {
        _super.apply(this, arguments);
    }
    var d = __define,c=MyInfo,p=c.prototype;
    MyInfo.getInstance = function () {
        if (!MyInfo._myInfo) {
            MyInfo._myInfo = new MyInfo();
        }
        return MyInfo._myInfo;
    };
    p.addBgViewHandler = function () {
        this.bgImag = GameUtils.createBitmapByName("bgImage");
        this.bgImag.width = 480;
        this.bgImag.height = 800;
        this.bgImag.visible = true;
    };
    p.setBgVisible = function (flag) {
        this.bgImag.visible = flag;
    };
    MyInfo._myInfo = null;
    return MyInfo;
}(egret.Sprite));
egret.registerClass(MyInfo,'MyInfo');
