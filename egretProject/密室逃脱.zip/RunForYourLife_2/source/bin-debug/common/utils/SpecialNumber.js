/**
 * Created by cf on 14-8-8.
 */
var SpecialNumber = (function (_super) {
    __extends(SpecialNumber, _super);
    function SpecialNumber() {
        _super.call(this);
        this.gap = 0;
    }
    var d = __define,c=SpecialNumber,p=c.prototype;
    /**
     * 设置显示的字符串
     */
    p.setData = function (str) {
        this.clear();
        if (str == "" || str == null)
            return;
        var chars = str.split("");
        var w = 0;
        var length = chars.length;
        for (var i = 0; i < length; i++) {
            var str = chars[i];
            try {
                var image = GameUtils.createBitmapFromSheet(str);
                if (image) {
                    image.x = w;
                    w += image.width + this.gap;
                    this.addChild(image);
                }
            }
            catch (e) {
                console.log(e);
            }
        }
        this.anchorOffsetX = this.width / 2;
    };
    p.clear = function () {
        while (this.numChildren) {
            this.removeChildAt(0);
        }
    };
    return SpecialNumber;
}(egret.DisplayObjectContainer));
egret.registerClass(SpecialNumber,'SpecialNumber');
