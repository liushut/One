/**
 * Created by lcj on 14-6-17.
 */
var GameUtils = (function () {
    function GameUtils() {
    }
    var d = __define,c=GameUtils,p=c.prototype;
    /**
     * 根据name关键字创建一个Bitmap对象。name属性请参考resources/resource.json配置文件的内容。
     */
    GameUtils.createBitmapByName = function (name) {
        var result = new egret.Bitmap();
        var texture = RES.getRes(name);
        result.texture = texture;
        return result;
    };
    /**
     * 根据name关键字创建一个Bitmap对象。此name 是根据TexturePacker 组合成的一张位图
     */
    GameUtils.createBitmapFromSheet = function (name, sheetName) {
        if (sheetName === void 0) { sheetName = "gameRes"; }
        var sheet = RES.getRes(sheetName);
        var texture = sheet.getTexture(name);
        var result = new egret.Bitmap();
        result.texture = texture;
        return result;
    };
    GameUtils.getTextureFromSheet = function (name, sheetName) {
        if (sheetName === void 0) { sheetName = "gameRes"; }
        var sheet = RES.getRes(sheetName);
        var result = sheet.getTexture(name);
        return result;
    };
    GameUtils.removeChild = function (child) {
        if (child && child.parent) {
            if (child.parent.removeElement) {
                child.parent.removeElement(child);
            }
            else {
                child.parent.removeChild(child);
            }
        }
    };
    GameUtils.addUI = function (ui) {
        if (ui && !ui.parent) {
            GameApp.uiStage.addElement(ui);
        }
    };
    GameUtils.removeUI = function (ui) {
        if (ui && ui.parent) {
            GameApp.uiStage.removeElement(ui);
        }
    };
    GameUtils.removeStarlingSwfUI = function (ui) {
        GameUtils.removeChild(ui);
    };
    GameUtils.getUrl = function (url) {
        return url != "" ? url : "";
    };
    GameUtils.addTouchTapListener = function (display, listener, thisObj) {
        var startX = -1;
        var startY = -1;
        display.touchEnabled = true;
        display.addEventListener(egret.TouchEvent.TOUCH_BEGIN, function (event) {
            startX = event.stageX;
            startY = event.stageY;
        }, display);
        display.addEventListener(egret.TouchEvent.TOUCH_END, function (event) {
            if (Math.abs(startX - event.stageX) < 10 && Math.abs(startY - event.stageY) < 10) {
                listener.call(thisObj);
            }
            startX = -1;
            startY = -1;
        }, display);
    };
    GameUtils.fixNumber = function (num) {
        var result = "";
        if (num > 10000) {
            num = Math.floor(num / 10000);
            result = num.toString() + "w";
        }
        else {
            result = num.toString();
        }
        return result;
    };
    GameUtils.lock = function (key) {
        var stage = egret.MainContext.instance.stage;
        stage.touchEnabled = stage.touchChildren = false;
    };
    GameUtils.unlock = function (key) {
        //todo key
        var stage = egret.MainContext.instance.stage;
        stage.touchEnabled = stage.touchChildren = true;
    };
    GameUtils.replaceTextureByUrl = function (url, obj) {
        RES.getResByUrl(url, function (texture) {
            obj.texture = texture;
        }, this, RES.ResourceItem.TYPE_IMAGE);
    };
    GameUtils.getIsTodayFirstIn = function () {
        var date = new Date();
        var lastDate = window.localStorage.getItem("LoginDate");
        if (lastDate == null) {
            lastDate = date.getMonth().toString() + date.getDay().toString();
            window.localStorage.setItem("LoginDate", lastDate);
            return true;
        }
        else {
            var currentDate = date.getMonth().toString() + date.getDay().toString();
            window.localStorage.setItem("LoginDate", currentDate);
            return currentDate != lastDate;
        }
    };
    return GameUtils;
}());
egret.registerClass(GameUtils,'GameUtils');
