/**
 * Created by Administrator on 2014/6/13.
 */
var Consts = (function () {
    function Consts() {
    }
    var d = __define,c=Consts,p=c.prototype;
    Consts.GAME_WIDTH = 480;
    Consts.GAME_HEIGHT = 650;
    return Consts;
}());
egret.registerClass(Consts,'Consts');
