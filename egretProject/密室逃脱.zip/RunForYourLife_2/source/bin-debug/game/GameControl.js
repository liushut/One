/**
 * Created by ismole on 14-8-8.
 */
var GameControl = (function (_super) {
    __extends(GameControl, _super);
    function GameControl() {
        _super.call(this);
        this.startgame = new StartGameLayer();
        this.gameScene = new GameSceneLayer();
        this.gameoverGame = new GameOverLayer();
    }
    var d = __define,c=GameControl,p=c.prototype;
    GameControl.getInstance = function () {
        if (!GameControl._gameControl) {
            GameControl._gameControl = new GameControl();
        }
        return GameControl._gameControl;
    };
    p.setStageHandler = function (stage) {
        this.currStage = stage;
        this.bgImag = GameUtils.createBitmapByName("bgImage");
        this.bgImag.width = 480;
        this.bgImag.height = 800;
        this.currStage.addChild(this.bgImag);
    };
    p.startGameHandler = function () {
        if (this.gameScene && this.gameScene.parent) {
            GameUtils.removeChild(this.gameScene);
        }
        if (this.gameoverGame && this.gameoverGame.parent) {
            GameUtils.removeChild(this.gameoverGame);
        }
        this.currStage.addChild(this.startgame);
        GameApp.xia.visible = true;
    };
    p.onGameSceneHandler = function () {
        if (this.startgame && this.startgame.parent) {
            GameUtils.removeChild(this.startgame);
        }
        if (this.gameoverGame && this.gameoverGame.parent) {
            GameUtils.removeChild(this.gameoverGame);
        }
        this.currStage.addChild(this.gameScene);
        GameApp.xia.visible = false;
    };
    p.showGameOverSceneHandler = function () {
        if (this.startgame && this.startgame.parent) {
            GameUtils.removeChild(this.startgame);
        }
        if (this.gameScene && this.gameScene.parent) {
            GameUtils.removeChild(this.gameScene);
        }
        this.currStage.addChild(this.gameoverGame);
        GameApp.xia.visible = true;
    };
    p.getGameOverDisplay = function () {
        return this.gameoverGame;
    };
    GameControl._gameControl = null;
    return GameControl;
}(egret.Sprite));
egret.registerClass(GameControl,'GameControl');
