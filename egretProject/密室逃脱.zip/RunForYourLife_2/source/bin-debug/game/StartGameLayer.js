/**
 * 开始游戏界面
 * Created by cf on 14-8-8.
 */
var StartGameLayer = (function (_super) {
    __extends(StartGameLayer, _super);
    function StartGameLayer() {
        _super.call(this);
        this.init();
    }
    var d = __define,c=StartGameLayer,p=c.prototype;
    p.init = function () {
        this.titleImage = GameUtils.createBitmapFromSheet("logo_mishitaosheng");
        this.titleImage.x = 51;
        this.titleImage.y = 161;
        this.addChild(this.titleImage);
        this.startBtn = new MyButton("btn_y", "btn_kaishi");
        this.startBtn.x = 131;
        this.startBtn.y = 324;
        this.startBtn.setClick(this.onStartGameClick);
        this.addChild(this.startBtn);
        this.moreBtn = new MyButton("btn_b", "btn_gengduo");
        //this.moreBtn.setClick(function(){EgretShare.moreGame()});
        this.moreBtn.x = 131;
        this.moreBtn.y = 432;
        if (egret.MainContext.RUNTIME_HTML5 == egret.Capabilities.runtimeType)
            this.addChild(this.moreBtn);
        var txt = new egret.TextField();
        txt.width = Consts.GAME_WIDTH;
        txt.textAlign = egret.HorizontalAlign.CENTER;
        txt.strokeColor = 0x403e3e;
        txt.stroke = 1;
        txt.bold = true;
        txt.y = 612;
        txt.text = "Powered by Egret Engine";
        this.addChild(txt);
    };
    p.onStartGameClick = function () {
        GameControl.getInstance().onGameSceneHandler();
    };
    return StartGameLayer;
}(egret.Sprite));
egret.registerClass(StartGameLayer,'StartGameLayer');
