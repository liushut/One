/**
 * Created by Administrator on 2014/8/9.
 */
var Shake = (function () {
    function Shake() {
    }
    var d = __define,c=Shake,p=c.prototype;
    p.run = function (obj, shakeNum, overFunc) {
        if (overFunc === void 0) { overFunc = null; }
        this.obj = obj;
        this.initY = obj.y;
        this.shakeNum = shakeNum;
        this.overFunc = overFunc;
        egret.startTick(this.loop, this);
        this.num = 0;
        this.flag = 0;
    };
    p.loop = function () {
        if (this.flag == 0) {
            if (this.obj.y <= this.initY) {
                this.obj.y += 5;
            }
            else {
                this.obj.y -= 5;
            }
            if (this.obj.y == this.initY) {
                this.num++;
                if (this.num == this.shakeNum) {
                    egret.stopTick(this.loop, this);
                    if (this.overFunc) {
                        this.overFunc();
                    }
                }
            }
        }
        this.flag++;
        if (this.flag == 2) {
            this.flag = 0;
        }
        return false;
    };
    return Shake;
}());
egret.registerClass(Shake,'Shake');
