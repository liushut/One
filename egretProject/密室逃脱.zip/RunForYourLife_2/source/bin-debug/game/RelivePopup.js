/**
 * Created by husong on 14/11/4.
 */
var RelivePopup = (function (_super) {
    __extends(RelivePopup, _super);
    function RelivePopup() {
        _super.call(this);
        this.addChildAt(this.getMask(), 0);
        this.btnRelive = new MyButton("btn_y", "btn_zaiwan");
        this.btnRelive.setTitle("fuhuo");
        this.btnRelive.x = 131;
        this.btnRelive.y = 245;
        //        this.tryBtn.setClick(this.onReliveClick);
        this.btnRelive.setClick(this.onReliveClick);
        this.addChild(this.btnRelive);
        this.btnOver = new MyButton("btn_b", "btn_zaiwan");
        this.btnOver.setTitle("jieshu");
        this.btnOver.x = 131;
        this.btnOver.y = 351;
        this.addChild(this.btnOver);
    }
    var d = __define,c=RelivePopup,p=c.prototype;
    p.onReliveClick = function () {
        //GameControl.getInstance().onReliveHandler();
    };
    p.getMask = function () {
        var spr = new egret.Sprite();
        spr.graphics.beginFill(0x000000, 0.4);
        spr.graphics.drawRect(0, 0, Consts.GAME_WIDTH, Consts.GAME_HEIGHT);
        spr.graphics.endFill();
        return spr;
    };
    return RelivePopup;
}(egret.DisplayObjectContainer));
egret.registerClass(RelivePopup,'RelivePopup');
