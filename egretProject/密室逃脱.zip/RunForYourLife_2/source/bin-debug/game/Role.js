/**
 * Created by Administrator on 2014/8/8.
 */
var Role = (function (_super) {
    __extends(Role, _super);
    function Role() {
        _super.call(this);
        this.currFrameIndex = 0;
        this.body = new egret.Bitmap();
        this.body.texture = GameUtils.getTextureFromSheet(Role.FRAMES[0][0], "roleRes");
        console.log(this.body.width);
        this.body.anchorOffsetX = this.body.width * 0.5;
        this.addChild(this.body);
    }
    var d = __define,c=Role,p=c.prototype;
    p.setState = function (state) {
        this.state = state;
        if (this.state == Role.STATE5) {
            this.isLoop = false;
            console.log("body height" + this.body.height);
            this.body.anchorOffsetY = this.body.height * 0;
        }
        else {
            this.isLoop = true;
            console.log("isloop body height" + this.body.height);
            this.body.anchorOffsetY = this.body.height * 1;
        }
        if (this.state == Role.STATE3 || this.state == Role.STATE4) {
            this.currFrames = [];
            if (Math.random() > 0.5) {
                this.currFrames.push(Role.FRAMES[this.state][0]);
            }
            else {
                this.currFrames.push(Role.FRAMES[this.state][1]);
            }
        }
        else {
            this.currFrames = Role.FRAMES[this.state];
        }
        this.currFrameIndex = 0;
        this.setBody();
    };
    p.setBody = function () {
        this.body.texture = GameUtils.getTextureFromSheet(this.currFrames[this.currFrameIndex], "roleRes");
        this.body.anchorOffsetX = this.body.width * 0.5;
        if (this.state == Role.STATE5) {
            this.isLoop = false;
            console.log("body height" + this.body.height);
            this.body.anchorOffsetY = this.body.height * 0;
        }
        else {
            this.isLoop = true;
            console.log("isloop body height" + this.body.height);
            this.body.anchorOffsetY = this.body.height * 1;
        }
    };
    p.run = function () {
        this.runFlag++;
        if (this.runFlag > 4) {
            this.runFlag = 0;
        }
        if (this.runFlag != 0) {
            return;
        }
        var gotoFrameIndex = this.currFrameIndex + 1;
        if (gotoFrameIndex == this.currFrames.length) {
            if (this.isLoop) {
                gotoFrameIndex = 0;
            }
            else {
                gotoFrameIndex = this.currFrameIndex;
            }
        }
        if (gotoFrameIndex != this.currFrameIndex) {
            this.currFrameIndex = gotoFrameIndex;
            this.setBody();
        }
        return false;
    };
    p.play = function () {
        egret.startTick(this.run, this);
        this.runFlag = 0;
    };
    p.stop = function () {
        egret.stopTick(this.run, this);
    };
    Role.STATE1 = 0;
    Role.STATE2 = 1;
    Role.STATE3 = 2;
    Role.STATE4 = 3;
    Role.STATE5 = 4;
    Role.FRAMES = [
        ["0020003", "0020004", "0020005", "0020006", "0020007"],
        ["0020008"],
        ["0020009", "0020010"],
        ["0020011", "0020012"],
        ["xue0001", "xue0002", "xue0003", "xue0004", "xue0005"]
    ];
    return Role;
}(egret.Sprite));
egret.registerClass(Role,'Role');
