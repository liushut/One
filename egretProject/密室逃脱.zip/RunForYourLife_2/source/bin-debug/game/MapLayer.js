/**
 * Created by ismole on 14-8-8.
 */
var MapLayer = (function () {
    function MapLayer() {
    }
    var d = __define,c=MapLayer,p=c.prototype;
    return MapLayer;
}());
egret.registerClass(MapLayer,'MapLayer');
