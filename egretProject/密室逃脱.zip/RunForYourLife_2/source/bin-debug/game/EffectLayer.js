/**
 * 特效的播放类
 * Created by ismole on 14-8-8.
 */
var EffectLayer = (function () {
    function EffectLayer() {
    }
    var d = __define,c=EffectLayer,p=c.prototype;
    return EffectLayer;
}());
egret.registerClass(EffectLayer,'EffectLayer');
