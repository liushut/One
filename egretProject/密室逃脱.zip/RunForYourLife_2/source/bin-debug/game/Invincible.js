/**
 * Created by husong on 14/11/4.
 */
var Invincible = (function (_super) {
    __extends(Invincible, _super);
    function Invincible() {
        _super.call(this);
        this.initUI();
    }
    var d = __define,c=Invincible,p=c.prototype;
    p.initUI = function () {
        this.upContainer = new egret.DisplayObjectContainer();
        this.upContainer.visible = false;
        this.addChild(this.upContainer);
        this.btnInvincible = new MyButton("btn_y", "btn_zaiwan");
        this.btnInvincible.setTitle("wudi");
        var bg = GameUtils.createBitmapFromSheet("framebg", "newAssets");
        bg.touchEnabled = false;
        bg.width = this.btnInvincible.width - 5;
        bg.height = 280;
        this.upContainer.addChild(bg);
        var gap = 65;
        var start = 80;
        this.btnOne = new MyButton("btn_b", "btn_zaiwan");
        this.btnOne.bg.scaleX = this.btnOne.bg.scaleY = 0.8;
        this.btnOne.setClick(this.oneTimeClick.bind(this));
        this.btnOne.y = start;
        this.btnOne.setTitle("1ci");
        this.upContainer.addChild(this.btnOne);
        this.btnTwo = new MyButton("btn_b", "btn_zaiwan");
        this.btnTwo.bg.scaleX = this.btnTwo.bg.scaleY = 0.8;
        this.btnTwo.setClick(this.twoTimeClick.bind(this));
        this.btnTwo.y = start + gap;
        this.btnTwo.setTitle("2ci");
        this.upContainer.addChild(this.btnTwo);
        this.btnThree = new MyButton("btn_b", "btn_zaiwan");
        this.btnThree.bg.scaleX = this.btnThree.bg.scaleY = 0.8;
        this.btnThree.setClick(this.threeTimeClick.bind(this));
        this.btnThree.y = start + gap * 2;
        this.btnThree.setTitle("3ci");
        this.upContainer.addChild(this.btnThree);
        this.addChild(this.btnInvincible);
        bg.x = this.width / 2 - (this.btnInvincible.width - 5) / 2;
        this.btnOne.x = this.width / 2 - this.btnOne.width / 2;
        this.btnTwo.x = this.width / 2 - this.btnTwo.width / 2;
        this.btnThree.x = this.width / 2 - this.btnThree.width / 2;
        this.btnInvincible.setClick(this.invincibleClick.bind(this));
    };
    p.invincibleClick = function () {
        this.upContainer.visible = !this.upContainer.visible;
        this.checkGameScene();
    };
    p.oneTimeClick = function () {
        this.upContainer.visible = !this.upContainer.visible;
        this.checkGameScene();
        //GameUtils.addUnDeadTimes(1);
    };
    p.twoTimeClick = function () {
        this.upContainer.visible = !this.upContainer.visible;
        this.checkGameScene();
        //GameUtils.addUnDeadTimes(2);
    };
    p.threeTimeClick = function () {
        this.upContainer.visible = !this.upContainer.visible;
        this.checkGameScene();
        //GameUtils.addUnDeadTimes(3);
    };
    p.removeTouch = function () {
        this.btnOne.touchEnabled = false;
        this.btnTwo.touchEnabled = false;
        this.btnThree.touchEnabled = false;
    };
    p.addTouch = function () {
        this.btnOne.touchEnabled = true;
        this.btnTwo.touchEnabled = true;
        this.btnThree.touchEnabled = true;
    };
    p.checkGameScene = function () {
        if (this.upContainer.visible) {
        }
        else {
        }
    };
    return Invincible;
}(egret.DisplayObjectContainer));
egret.registerClass(Invincible,'Invincible');
