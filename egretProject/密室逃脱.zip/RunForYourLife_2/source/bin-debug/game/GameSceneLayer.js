/**
 * 游戏场景
 * Created by ismole on 14-8-8.
 */
var GameSceneLayer = (function (_super) {
    __extends(GameSceneLayer, _super);
    function GameSceneLayer() {
        _super.call(this);
        this.spaceArr = [50, 70, 90, 110];
        this.initUI();
    }
    var d = __define,c=GameSceneLayer,p=c.prototype;
    p.initUI = function () {
        this.shake1 = new Shake();
        this.shake2 = new Shake();
        this.bg = RES.getRes("bg_qiang");
        var bg = new egret.Bitmap(this.bg);
        bg.mask = new egret.Rectangle(0, Consts.GAME_HEIGHT, Consts.GAME_WIDTH, 300);
        this.addChild(bg);
        this.bgBitmaps = new Array();
        this.topContianer = new egret.Sprite();
        this.addChild(this.topContianer);
        this.topSptite = new egret.Sprite();
        this.topContianer.addChild(this.topSptite);
        this.topLine = new egret.Shape();
        this.topContianer.addChild(this.topLine);
        this.bottomContianer = new egret.Sprite();
        this.addChild(this.bottomContianer);
        this.bottomSptite = new egret.Sprite();
        this.bottomContianer.addChild(this.bottomSptite);
        this.bottomLine = new egret.Shape();
        this.bottomContianer.addChild(this.bottomLine);
        this.topRects = new Array();
        this.bottomRects = new Array();
        this.titleImg = GameUtils.createBitmapFromSheet("bg_shangkuang");
        this.addChild(this.titleImg);
        this.scoreKuang = GameUtils.createBitmapFromSheet("kuang");
        this.scoreKuang.x = 5;
        this.addChild(this.scoreKuang);
        this.lvKuang = GameUtils.createBitmapFromSheet("kuang");
        this.lvKuang.scaleX = -1;
        this.lvKuang.x = 466;
        this.addChild(this.lvKuang);
        this.maxScore = GameUtils.createBitmapFromSheet("fenshu");
        this.maxScore.x = 40;
        this.maxScore.y = 15;
        this.addChild(this.maxScore);
        this.currLv = GameUtils.createBitmapFromSheet("guanqia");
        this.currLv.x = 368;
        this.currLv.y = 15;
        this.addChild(this.currLv);
        this.lvNum = new SpecialNumber();
        this.lvNum.x = 393;
        this.lvNum.y = 50;
        this.addChild(this.lvNum);
        this.recordNum = new SpecialNumber();
        this.recordNum.x = 73;
        this.recordNum.y = 50;
        this.addChild(this.recordNum);
        this.currLevel = 1;
        this.currMaxScore = 0;
        this.lvNum.setData(this.currLevel.toString());
        this.recordNum.setData(this.currMaxScore.toString());
        this.role = new Role();
        this.addChild(this.role);
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdd, this);
    };
    p.onAdd = function () {
        this.dieNum = 0;
        this.score = 0;
        this.currLevel = 1;
        this.refreshScore();
        this.initData();
        egret.setTimeout(this.start, this, 100);
    };
    p.refreshScore = function () {
        this.lvNum.setData(this.currLevel.toString());
        this.recordNum.setData(this.score.toString());
    };
    p.refurbish = function () {
        this.initData();
        this.start();
    };
    p.start = function () {
        this.stage.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        egret.setTimeout(this.shakeRun, this, 1000);
    };
    p.shakeRun = function () {
        this.shake1.run(this.topContianer, 5, this.land.bind(this));
    };
    p.land = function () {
        this.stage.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClick, this);
        egret.Tween.get(this.topContianer).to({ "y": 0 }, 100).call(function () {
            this.landOver();
        }.bind(this));
    };
    p.landOver = function () {
        this.checkState();
        this.shake1.run(this.topContianer, 3);
        this.shake2.run(this.bottomContianer, 3, this.checkResult.bind(this));
    };
    p.checkState = function () {
        var space = this.getSpace();
        if (space == 0) {
            this.role.setState(Role.STATE5);
        }
        else if (space == this.spaceArr[2]) {
            this.role.setState(Role.STATE4);
        }
        else if (space == this.spaceArr[0]) {
            this.role.setState(Role.STATE3);
        }
        else if (space == this.spaceArr[1]) {
            this.role.setState(Role.STATE2);
        }
        if (space == 0) {
            this.setRolePos(this.rolePosIndex, -10, 4);
        }
    };
    p.checkResult = function () {
        var space = this.getSpace();
        var _this = this;
        if (space == 0) {
            this.dieNum++;
            if (this.dieNum == 1) {
                this.role.stop();
                egret.setTimeout(function () {
                    GameControl.getInstance().showGameOverSceneHandler();
                    GameControl.getInstance().getGameOverDisplay().setGameOverDataHandler(_this.score, _this.currMaxScore);
                }, this, 1000);
                return;
            }
        }
        else {
            this.currLevel++;
            this.score += 10;
            if (this.score > this.currMaxScore) {
                this.currMaxScore = this.score;
            }
            this.refreshScore();
        }
        egret.setTimeout(this.refurbish, this, 1000);
    };
    p.getSpace = function () {
        var top = this.topRects[this.rolePosIndex];
        var bottom = this.bottomRects[this.rolePosIndex];
        return Consts.GAME_HEIGHT - top.height - bottom.height;
    };
    p.onClick = function (e) {
        var i = 0;
        var len = this.bottomRects.length;
        for (i; i < len; i++) {
            var rec = this.bottomRects[i];
            if (e.stageX > rec.x && e.stageX < rec.x + rec.width) {
                this.setRolePos(i);
                break;
            }
        }
    };
    p.initData = function () {
        this.role.setState(Role.STATE1);
        this.role.play();
        this.topRects.splice(0, this.topRects.length);
        this.bottomRects.splice(0, this.bottomRects.length);
        var min = 150;
        var w = 60;
        var flag = false;
        var len = 8;
        for (var i = 0; i < len; i++) {
            var h = min + Math.floor(Math.random() * 8) * 10;
            this.bottomRects.push(new egret.Rectangle(i * w, Consts.GAME_HEIGHT - h, w, h));
            h = Consts.GAME_HEIGHT - h;
            if (Math.random() < 0.2 || (!flag && i == len - 1)) {
                var index = Math.floor(Math.random() * this.spaceArr.length);
                h -= this.spaceArr[index];
                flag = true;
            }
            this.topRects.push(new egret.Rectangle(i * w, 0, w, h));
        }
        this.fullFront(this.topSptite, this.topRects);
        this.fullFront(this.bottomSptite, this.bottomRects, true);
        this.drawLine();
        this.topContianer.y = -200;
        this.setRolePos(3, 17, 0, true);
    };
    p.setRolePos = function (index, offY, offX, isInit) {
        if (offY === void 0) { offY = 17; }
        if (offX === void 0) { offX = 0; }
        if (isInit === void 0) { isInit = false; }
        if (!isInit) {
            if (this.rolePosIndex > index) {
                index = this.rolePosIndex - 1;
            }
            else if (this.rolePosIndex < index) {
                index = this.rolePosIndex + 1;
            }
        }
        this.rolePosIndex = index;
        var rec = this.bottomRects[index];
        this.role.x = rec.x + rec.width / 2 + offX;
        this.role.y = rec.y + offY;
    };
    p.drawLine = function () {
        var lineH = 10;
        this.topLine.graphics.clear();
        this.topLine.graphics.lineStyle(lineH, 0x33E7FE);
        this.bottomLine.graphics.clear();
        this.bottomLine.graphics.lineStyle(lineH, 0x33E7FE);
        this.drawTopLine(lineH / 2);
        this.drawBottomLine(lineH / 2);
        this.topLine.graphics.endFill();
        this.bottomLine.graphics.endFill();
    };
    p.drawTopLine = function (lineH) {
        var len = this.topRects.length;
        for (var i = 0; i < len; i++) {
            var rec = this.topRects[i];
            if (i == 0) {
                this.topLine.graphics.moveTo(rec.x, rec.height);
                this.topLine.graphics.lineTo(rec.x + rec.width, rec.height);
            }
            else {
                this.topLine.graphics.lineTo(rec.x, rec.height);
                this.topLine.graphics.lineTo(rec.x + rec.width, rec.height);
            }
        }
    };
    p.drawBottomLine = function (lineH) {
        var len = this.bottomRects.length;
        for (var i = 0; i < len; i++) {
            var rec = this.bottomRects[i];
            if (i == 0) {
                this.bottomLine.graphics.moveTo(rec.x, rec.y + lineH);
                this.bottomLine.graphics.lineTo(rec.x + rec.width, rec.y + lineH);
            }
            else {
                this.bottomLine.graphics.lineTo(rec.x, rec.y + lineH);
                this.bottomLine.graphics.lineTo(rec.x + rec.width, rec.y + lineH);
            }
        }
    };
    p.fullFront = function (bgSptite, rects, isBottom) {
        if (isBottom === void 0) { isBottom = false; }
        bgSptite.cacheAsBitmap = false;
        this.clearBg(bgSptite);
        var len = rects.length;
        for (var i = 0; i < len; i++) {
            var rec = rects[i];
            var bitmap;
            if (this.bgBitmaps.length) {
                bitmap = this.bgBitmaps.pop();
            }
            else {
                bitmap = new egret.Bitmap();
                bitmap.texture = this.bg;
            }
            bitmap.scrollRect = rec;
            bitmap.x = rec.x;
            bitmap.y = rec.y;
            bgSptite.addChild(bitmap);
        }
    };
    p.clearBg = function (bgSptite) {
        while (bgSptite.numChildren) {
            var bitmap = bgSptite.getChildAt(0);
            if (bitmap) {
                bgSptite.removeChild(bitmap);
                this.bgBitmaps.push(bitmap);
            }
        }
    };
    return GameSceneLayer;
}(egret.Sprite));
egret.registerClass(GameSceneLayer,'GameSceneLayer');
