
var game_file_list = [
    //以下为自动修改，请勿修改
    //----auto game_file_list start----
	"libs/modules/egret/egret.js",
	"libs/modules/egret/egret.native.js",
	"libs/modules/game/game.js",
	"libs/modules/game/game.native.js",
	"libs/modules/tween/tween.js",
	"libs/modules/res/res.js",
	"libs/modules/dragonbones/dragonbones.js",
	"libs/modules/gui/gui.js",
	"bin-debug/AlertPanel.js",
	"bin-debug/common/utils/GameUtils.js",
	"bin-debug/common/utils/MyButton.js",
	"bin-debug/common/utils/MyInfo.js",
	"bin-debug/common/utils/ShareUtils.js",
	"bin-debug/common/utils/SpecialNumber.js",
	"bin-debug/Consts.js",
	"bin-debug/game/EffectLayer.js",
	"bin-debug/game/GameControl.js",
	"bin-debug/game/GameOverLayer.js",
	"bin-debug/game/GameSceneLayer.js",
	"bin-debug/game/Invincible.js",
	"bin-debug/game/MapLayer.js",
	"bin-debug/game/PlayerLayer.js",
	"bin-debug/game/RelivePopup.js",
	"bin-debug/game/Role.js",
	"bin-debug/game/Shake.js",
	"bin-debug/game/StartGameLayer.js",
	"bin-debug/GameApp.js",
	"bin-debug/LoadingUI.js",
	"bin-debug/Main.js",
	//----auto game_file_list end----
];

var window = this;

egret_native.setSearchPaths([""]);

egret_native.requireFiles = function () {
    for (var key in game_file_list) {
        var src = game_file_list[key];
        require(src);
    }
};

egret_native.egretInit = function () {
    egret_native.requireFiles();
    egret.TextField.default_fontFamily = "/system/fonts/DroidSansFallback.ttf";
    //egret.dom为空实现
    egret.dom = {};
    egret.dom.drawAsCanvas = function () {
    };
};

egret_native.egretStart = function () {
    var option = {
        //以下为自动修改，请勿修改
        //----auto option start----
		entryClassName: "GameApp",
		frameRate: 30,
		scaleMode: "showAll",
		contentWidth: 480,
		contentHeight: 800,
		showPaintRect: false,
		showFPS: false,
		fpsStyles: "x:0,y:0,size:30,textColor:0x00c200,bgAlpha:0.9",
		showLog: false,
		logFilter: "",
		maxTouches: 2,
		textureScaleFactor: 1
		//----auto option end----
    };

    egret.native.NativePlayer.option = option;
    egret.runEgret();
    egret_native.Label.createLabel(egret.TextField.default_fontFamily, 20, "", 0);
    egret_native.EGTView.preSetOffScreenBufferEnable(true);
};