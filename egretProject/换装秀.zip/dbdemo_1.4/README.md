### Egret 换装秀示例

--- 

点击不同的分类在试衣间完成换装。

演示基本骨骼动画和程序换装效果。

#### 更多

DragonBones 最新版：[DragonBones下载](http://www.egret.com/dragonbones)
DragonBones Egret API:[DragonBones](http://edn.egret.com/cn/apidoc/index/name/dragonBones.Animation)
获得更多DragonBones教程：[DragonBones](http://edn.egret.com/cn/docs/page/364)
