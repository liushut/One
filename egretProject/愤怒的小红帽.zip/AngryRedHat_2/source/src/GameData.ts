/**
 * Created by Channing on 2014/9/17.
 */
class GameData{

    public static closeMusic:Boolean = false;
    public static closeBgMusic:Boolean = false;
    public static isClickBtn:Boolean = false;
    public static isStart:Boolean = false;
    public static num:Array<any> = ["1","0",".","0",".","4",".","1","8","0",":","3","0","0","0"];
    public static curScene:number = 1;
    public static isPause:Boolean = true;
    public static redGirlDistance:number = 0;
    public static sorce:number =0;
    public static blod:number = 5;
    public static enemySpeed:number = 0;
    public static stopCreateEnemy:number = 0;
    public static stopEnemyBoo:Boolean = false;
    public static count:number = 0;
    public static bgSpeed:number = 0;
    public static profectNum:number = 0;
    public static langNum:number = 0
    public static huliNum:number = 0
    public static bianfuNum:number = 0
    public static dazhaoTime:number = 50;
    public static isWin:Boolean = false;
    public static isStartClickOption:Boolean = false;
    public static dubleSorce:Boolean = false;
    public static curTimeNum:number = 0;
    public static sheDie:Boolean = false;
    public static sheTimeNum:number = 0;
}