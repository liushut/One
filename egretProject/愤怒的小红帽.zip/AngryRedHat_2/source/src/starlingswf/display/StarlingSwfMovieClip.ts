/**
 * Created by Administrator on 2014/9/29.
 */
class StarlingswfMovieClip{
    public static swfFrame:any = egret.getDefinitionByName(SwfFrameInfo.swfNum);

}