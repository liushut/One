/**
 * Created by Channing on 2014/9/29.
 */
class SwfAnimationInfo{
    public static arr:Array<any> = ["l","o","c","a","t","i","o","n"];
}
