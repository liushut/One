/**
 * Created by Channing on 2014/10/14.
 */
class Daoju extends egret.Sprite
{
    constructor(num:number = 0)
    {
        super();
        this.initView(num);
    }
    private initView(num:number = 0):void
    {

    }
}