/**
 * Created by Administrator on 2014/9/29.
 */
class GS{
    public static bb:number = 1010101010000010;

}