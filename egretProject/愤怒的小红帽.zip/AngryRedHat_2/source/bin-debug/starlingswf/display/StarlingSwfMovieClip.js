/**
 * Created by Administrator on 2014/9/29.
 */
var StarlingswfMovieClip = (function () {
    function StarlingswfMovieClip() {
    }
    var d = __define,c=StarlingswfMovieClip,p=c.prototype;
    StarlingswfMovieClip.swfFrame = egret.getDefinitionByName(SwfFrameInfo.swfNum);
    return StarlingswfMovieClip;
}());
egret.registerClass(StarlingswfMovieClip,'StarlingswfMovieClip');
