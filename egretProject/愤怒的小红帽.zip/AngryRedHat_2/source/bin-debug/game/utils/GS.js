/**
 * Created by Administrator on 2014/9/29.
 */
var GS = (function () {
    function GS() {
    }
    var d = __define,c=GS,p=c.prototype;
    GS.bb = 1010101010000010;
    return GS;
}());
egret.registerClass(GS,'GS');
