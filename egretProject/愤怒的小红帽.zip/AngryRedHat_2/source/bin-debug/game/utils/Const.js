/**
 * Created by Channing on 2014/9/17.
 */
var Const = (function () {
    function Const() {
    }
    var d = __define,c=Const,p=c.prototype;
    Const.SCENT_WIDTH = 0;
    Const.SCENT_HEIGHT = 0;
    Const.GamePoxY = 0;
    Const.setSwfArr = ["s", "t", "a", "t", "i", "c", ".", "e", "g", "r", "e", "t", "-", "l", "a", "b", "s", ".", "o", "r", "g"];
    return Const;
}());
egret.registerClass(Const,'Const');
