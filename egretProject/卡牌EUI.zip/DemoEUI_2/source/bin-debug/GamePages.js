/**
 * Created by egret on 2016/1/26.
 */
var GamePages = (function () {
    function GamePages() {
    }
    var d = __define,c=GamePages,p=c.prototype;
    GamePages.PROFILE = "profile";
    GamePages.HEROS = "heros";
    GamePages.GOODS = "goods";
    GamePages.ABOUT = "about";
    GamePages.HOME = "home";
    return GamePages;
})();
egret.registerClass(GamePages,'GamePages');
