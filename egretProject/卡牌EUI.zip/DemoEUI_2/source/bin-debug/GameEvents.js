/**
 * Created by egret on 2016/1/22.
 */
var GameEvents = (function () {
    function GameEvents() {
    }
    var d = __define,c=GameEvents,p=c.prototype;
    GameEvents.EVT_RETURN = "EVT_RETURN";
    GameEvents.EVT_LOAD_PAGE = "EVT_LOAD_PAGE";
    GameEvents.EVT_CLOSE_ABOUT = "EVT_CLOSE_ABOUT";
    return GameEvents;
})();
egret.registerClass(GameEvents,'GameEvents');
