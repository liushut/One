var Game = (function (_super) {
    __extends(Game, _super);
    function Game() {
        _super.call(this);
        this._bg = "";
        this._curReq = 0;
        this.st = 0;
    }
    var d = __define,c=Game;p=c.prototype;
    p.playLevel = function (levelname) {
        var obj = RES.getRes(levelname);
        this._reqs = [];
        this._bg = obj.bg;
        this._time = new egret.Timer(1000, obj.time);
        this.st = obj.time;
        var len = obj.req.length;
        for (var i = 0; i < len; i++) {
            var r = new Req();
            r.name = obj.req[i].name;
            r.rs = obj.req[i].IDS;
            r.ns = obj.req[i].num;
            this._reqs.push(r);
        }
        RES.loadGroup(obj.group);
        this._sv = new egret.ScrollView();
        this.addChild(this._sv);
        this._sv.width = this.stage.stageWidth;
        this._sv.height = this.stage.stageHeight - 100;
        this._reqtxt = new egret.TextField();
        this._reqtxt.width = this.stage.stageWidth / 2;
        this._reqtxt.height = 100;
        this._reqtxt.y = this.stage.stageHeight - 100;
        this.addChild(this._reqtxt);
        this._timetxt = new egret.TextField();
        this._timetxt.width = this._reqtxt.width;
        this._timetxt.height = 100;
        this._timetxt.x = this._reqtxt.width;
        this._timetxt.y = this._reqtxt.y;
        this.addChild(this._timetxt);
    };
    p.play = function () {
        var b = new egret.Bitmap();
        b.texture = RES.getRes(this._bg);
        b.width = this.stage.stageWidth;
        b.height = this.stage.stageHeight;
        this.addChildAt(b, 0);
        this._curReq = 0;
        var sp = this.createElements();
        this._sv.setContent(sp);
        this.playNew();
        this.startTime();
    };
    p.createElements = function () {
        var sp = new egret.DisplayObjectContainer();
        var cx = 0;
        var cy = 0;
        var ny = 0;
        for (var t = 0; t < 3; t++) {
            for (var i = 0; i < 13; i++) {
                var b = new egret.Bitmap();
                b.texture = RES.getRes(i + "_png");
                sp.addChild(b);
                if (cx + b.width > this.stage.stageWidth) {
                    cy = ny;
                    cx = 0;
                }
                b.x = cx;
                b.y = cy;
                cx += b.width;
                (cy + b.height) > ny ? ny = cy + b.height : ny = ny;
                b.touchEnabled = true;
                b.name = i.toString();
                b.addEventListener(egret.TouchEvent.TOUCH_TAP, this.click, this);
            }
        }
        return sp;
    };
    p.click = function (evt) {
        var rel = this.check(evt.target.name);
        if (rel) {
            evt.target.parent.removeChild(evt.target);
            this._reqs[this._curReq].ns--;
            this.update();
            if (this._reqs[this._curReq].ns == 0) {
                this._curReq++;
                this.playNew();
            }
        }
    };
    p.check = function (val) {
        var rel = false;
        var len = this._reqs[this._curReq].rs.length;
        for (var i = 0; i < len; i++) {
            if (val == this._reqs[this._curReq].rs[i].toString()) {
                return true;
            }
        }
        return rel;
    };
    p.playNew = function () {
        this.update();
    };
    p.update = function () {
        this._reqtxt.text = this._reqs[this._curReq].name + ": " + this._reqs[this._curReq].ns + "个";
    };
    p.startTime = function () {
        this._timetxt.text = "剩余时间：" + this.st + "秒";
        this._time.addEventListener(egret.TimerEvent.TIMER, this.tt, this);
        this._time.start();
    };
    p.tt = function (evt) {
        this.st--;
        this._timetxt.text = "剩余时间：" + this.st + "秒";
    };
    return Game;
})(egret.DisplayObjectContainer);
egret.registerClass(Game,"Game");
