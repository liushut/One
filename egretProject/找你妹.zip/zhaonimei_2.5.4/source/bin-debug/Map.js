var GameMap = (function (_super) {
    __extends(GameMap, _super);
    function GameMap() {
        _super.call(this);
        this._ps = [];
        this._currentLevel = 0;
    }
    var d = __define,c=GameMap;p=c.prototype;
    p.init = function () {
        var bg = new egret.Bitmap();
        bg.texture = RES.getRes("map_jpg");
        bg.width = this.stage.stageWidth;
        bg.height = this.stage.stageHeight;
        this.addChild(bg);
        var len = RES.getRes("map_json").level.length;
        for (var i = 0; i < len; i++) {
            var sh = new egret.Shape();
            sh.graphics.lineStyle(1, 0xff0000);
            sh.graphics.beginFill(0xffffff);
            sh.graphics.drawCircle(0, 0, 10);
            sh.graphics.endFill();
            sh.x = RES.getRes("map_json").level[i].x;
            sh.y = RES.getRes("map_json").level[i].y;
            sh.name = RES.getRes("map_json").level[i].ldata;
            this._ps.push(sh);
            this.addChild(sh);
        }
        this._player = new egret.Bitmap();
        this._player.touchEnabled = true;
        this._player.texture = RES.getRes("player_png");
        this._player.width = 50;
        this._player.height = 50;
        this._player.x = this._ps[this._currentLevel].x;
        this._player.y = this._ps[this._currentLevel].y;
        this.addChild(this._player);
    };
    p.gotoLevel = function (val) {
        this._currentLevel = val;
        egret.Tween.get(this._player).to({ x: this._ps[this._currentLevel].x, y: this._ps[this._currentLevel].y }, 700);
    };
    p.getLevelName = function () {
        return this._ps[this._currentLevel].name;
    };
    return GameMap;
})(egret.DisplayObjectContainer);
egret.registerClass(GameMap,"GameMap");
