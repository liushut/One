var Req = (function () {
    function Req() {
        this.name = "";
        this.rs = [];
        this.ns = 0;
    }
    var d = __define,c=Req;p=c.prototype;
    return Req;
})();
egret.registerClass(Req,"Req");
