class Game extends egret.DisplayObjectContainer
{
    public constructor()
    {
        super();
    }

    private _time:egret.Timer;
    private _reqs:Req[];
    private _bg:string = "";
    private _sv:egret.ScrollView;
    private _curReq:number=0;

    private _reqtxt:egret.TextField;
    private _timetxt:egret.TextField;
    public playLevel(levelname:string)
    {
        var obj = RES.getRes(levelname);
        this._reqs = [];
        this._bg = obj.bg;
        this._time = new egret.Timer(1000, obj.time);
        this.st = obj.time;
        var len:number = obj.req.length;
        for(var i=0;i<len;i++)
        {
            var r:Req = new Req();
            r.name = obj.req[i].name;
            r.rs = obj.req[i].IDS;
            r.ns = obj.req[i].num;
            this._reqs.push( r );
        }

        RES.loadGroup( obj.group );
        this._sv = new egret.ScrollView();
        this.addChild( this._sv );
        this._sv.width = this.stage.stageWidth;
        this._sv.height = this.stage.stageHeight - 100;

        this._reqtxt = new egret.TextField();
        this._reqtxt.width = this.stage.stageWidth / 2;
        this._reqtxt.height = 100;
        this._reqtxt.y = this.stage.stageHeight - 100;
        this.addChild( this._reqtxt );

        this._timetxt = new egret.TextField();
        this._timetxt.width = this._reqtxt.width;
        this._timetxt.height = 100;
        this._timetxt.x = this._reqtxt.width;
        this._timetxt.y = this._reqtxt.y;
        this.addChild( this._timetxt );
    }

    public play()
    {
        var b:egret.Bitmap = new egret.Bitmap();
        b.texture = RES.getRes(this._bg);
        b.width = this.stage.stageWidth;
        b.height = this.stage.stageHeight;
        this.addChildAt( b , 0);

        this._curReq = 0;
        var sp:egret.DisplayObjectContainer = this.createElements();
        this._sv.setContent( sp  );
        this.playNew();

        this.startTime();
    }

    private createElements():egret.DisplayObjectContainer
    {
        var sp:egret.DisplayObjectContainer = new egret.DisplayObjectContainer();

        var cx:number = 0;
        var cy:number = 0;
        var ny:number = 0;


        for(var t=0;t<3;t++)
        {
            for(var i=0;i<13;i++)
            {
                var b:egret.Bitmap = new egret.Bitmap();
                b.texture = RES.getRes(i+"_png");
                sp.addChild(b);
                if( cx+b.width > this.stage.stageWidth)
                {
                    cy = ny;
                    cx = 0;
                }

                b.x = cx;
                b.y = cy;

                cx += b.width;
                (cy+b.height)>ny?ny=cy+b.height:ny=ny;

                b.touchEnabled = true;
                b.name = i.toString();
                b.addEventListener(egret.TouchEvent.TOUCH_TAP,this.click,this);
            }
        }

        return sp;
    }
    private click(evt:egret.TouchEvent)
    {
        var rel:boolean = this.check( evt.target.name );
        if( rel )
        {

            evt.target.parent.removeChild(evt.target);
            this._reqs[this._curReq].ns--;
            this.update();

            if( this._reqs[this._curReq].ns==0 )
            {
                this._curReq ++;
                this.playNew();
            }
        }

    }
    private check(val:string):boolean
    {
        var rel:boolean = false;

        var len:number = this._reqs[this._curReq].rs.length;

        for(var i=0;i<len;i++)
        {
            if( val == this._reqs[this._curReq].rs[i].toString())
            {
                return true;
            }
        }
        return rel;
    }

    private playNew()
    {
        this.update();
    }
    private update()
    {

        this._reqtxt.text = this._reqs[this._curReq].name + ": " +this._reqs[this._curReq].ns+"个";
    }

    private st:number = 0;
    private startTime()
    {
        this._timetxt.text = "剩余时间：" + this.st + "秒";
        this._time.addEventListener(egret.TimerEvent.TIMER,this.tt,this);
        this._time.start();
    }
    private tt(evt:egret.TimerEvent)
    {
        this.st --;
        this._timetxt.text = "剩余时间：" + this.st + "秒";
    }

}