class Req
{
    public name:string = "";
    public rs:number[] = [];
    public ns:number=0;
}
